export const ROTA_COVERAGE_PATH = '/rota-coverage';

export const ROTA_COVERAGE_STATIC_PATH = '/static';

export const ROTA_COVERAGE_MOBILE_PATH = '/mobile';

export const DASH_BOARD_PATH = '/dashboard';

export const REPORT_PATH = '/report';

export const SETTING_PATH = '/setting';

export const SETTING_WARDEN_PATH = '/warden';

export const SETTING_LOCATION_PATH = '/location';

export const SETTING_CLUSTER_PATH = '/cluster';

export const LIEU_LEAVE_APPROVALS_PATH = '/ll-approvals'
