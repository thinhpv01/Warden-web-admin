export default function GreenBox() {
	return <div>GreenBox</div>;
}
