import { Stack, Typography } from '@mui/material';

const Coming = () => {
    return (
        <Stack>
            <Typography>Coming soon!</Typography>
        </Stack>
    );
};

export default Coming;
