const fonts = {
    firstFont: "TT Firs Neue",
    secondFont: "Poppins",
    thirdFont: "TT Firs Regular"
}

export default fonts;